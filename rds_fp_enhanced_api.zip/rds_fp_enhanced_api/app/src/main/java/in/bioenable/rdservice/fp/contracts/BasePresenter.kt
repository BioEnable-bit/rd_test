package `in`.bioenable.rdservice.fp.contracts

abstract class BasePresenter(view:BaseView)