package `in`.bioenable.rdservice.fp.contracts

interface Manager {

    fun disableClientCalls()

    fun enableClientCalls()
}