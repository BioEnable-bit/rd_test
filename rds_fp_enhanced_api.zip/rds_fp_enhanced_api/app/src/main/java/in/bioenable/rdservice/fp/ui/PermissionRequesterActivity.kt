package `in`.bioenable.rdservice.fp.ui

import android.Manifest
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.WindowManager
//import androidx.appcompat.app.AppCompatActivity

class PermissionRequesterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, 0)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

//        when(intent.getIntExtra()){
//
//        }
    }
}